class Row:
    
    def __init__(self, row):
        self.__tipoDocumento = row[0]
        self.__documento = row[1]
        self.__obligacionesDelClienteCerradasU12M = row[2]
        self.__mesesCuotasPagadasClientePorCredito = row[3]
        self.__valorDesembolsadoPorCredito = row[4]
        self.__moraIntrames = row[5]
        self.__clienteReestructurado = row[6]
        self.__clienteCobranzasONormalizado = row[7]
        self.__solicitudesRechazadasFlujoGPOU6M = row[8]
        self.__solicitudesPendientesEnGPO = row[9]
        self.__numeroObligacionesMayor500M = row[10]

    def getTipoDocumento(self):
        return self.__tipoDocumento
