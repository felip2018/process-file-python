import json
import boto3
import csv
import Row

s3 = boto3.client('s3')

def lambda_handler(event, context):
    print('Starting FileUpload lambda')
    
    bucket = event['Records'][0]['s3']['bucket']['name']
    key = event['Records'][0]['s3']['object']['key']

    try:
        file = s3.get_object(Bucket=bucket, Key=key)
        data = file['Body'].read().decode('utf-8').splitlines()

        lines = csv.reader(data)
        for line in lines:
            #print complete line
            arr = line[0].split(';')
            if(arr.__len__):
                row = Row(arr)
                print(row.getTipoDocumento())
                

    except Exception as e:
        print(e)
        print('Error obteniendo archivo ', key, ' del bucket', bucket)


